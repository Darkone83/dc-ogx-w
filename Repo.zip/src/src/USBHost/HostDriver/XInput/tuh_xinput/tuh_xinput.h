/*  

TinyUSB XInput host driver based on https://github.com/Ryzee119/tusb_xinput 

MIT License

Copyright (c) 2020 Ryan Wendland

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/

#ifndef _TUH_XINPUT_H_
#define _TUH_XINPUT_H_

#include <cstdint>
#include <array>

#include "tusb.h"
#include "host/usbh.h"
#include "host/usbh_pvt.h"

namespace tuh_xinput
{
    enum class DevType { UNKNOWN, XBOX360, XBOX360W, XBOXOG, XBOXONE };
    enum class ItfType { UNKNOWN, XID, CHATPAD };
    enum class ChatpadStage
    {
        INIT_1 = 0,
        INIT_2,
        INIT_3,
        INIT_4,
        INIT_5,
        INIT_6,
        KEEPALIVE_1,
        KEEPALIVE_2,
        LED_REQUEST
    };

    static constexpr uint8_t ENDPOINT_SIZE = 64;
    static constexpr uint32_t KEEPALIVE_MS = 1000;

    struct Interface
    {
        bool connected{false};
        /** Vendor-class GIP arcade stick (Razer Atrox XBO, etc.) — xpad MAP_TRIGGERS_TO_BUTTONS layout. */
        bool gip_arcade_stick{false};
        /** GIP OUT sequence byte (Linux xpad odata_serial). */
        uint8_t gip_out_seq{0};
        /**
         * When true, never assign host GIP sequence 0 (xone data_sequence behavior).
         * Used by Victrix Gambit only — other Xbox paths keep legacy 0-start sequencing.
         */
        bool gip_seq_skip_zero{false};
        /** Linux xpad sends xboxone_power_on once; repeats make arcade sticks flash/cycle power. */
        bool gip_power_sent{false};
        /** Last successful GIP IN xfer (ms); used to re-arm IN only when the chain stalls. */
        uint32_t gip_last_in_ok_ms{0};
        uint32_t gip_last_in_arm_ms{0};

        DevType dev_type{DevType::UNKNOWN};
        ItfType itf_type{ItfType::UNKNOWN};

        bool chatpad_inited{false};
        ChatpadStage chatpad_stage{ChatpadStage::INIT_1};

        uint8_t dev_addr{0xFF};
        uint8_t itf_num{0xFF};

        uint8_t ep_in{0xFF};
        uint8_t ep_out{0xFF};

        uint16_t ep_in_size{0xFF};
        uint16_t ep_out_size{0xFF};

        std::array<uint8_t, ENDPOINT_SIZE> ep_in_buffer{0};
        std::array<uint8_t, ENDPOINT_SIZE> ep_out_buffer{0};
    };

    // API

    const usbh_class_driver_t* class_driver();

    bool send_report(uint8_t address, uint8_t instance, const uint8_t* report, uint16_t len);
    bool receive_report(uint8_t address, uint8_t instance);
    bool set_rumble(uint8_t address, uint8_t instance, uint8_t rumble_l, uint8_t rumble_r, bool block);
    bool set_led(uint8_t address, uint8_t instance, uint8_t led_number, bool block);
    bool is_connected(uint8_t address, uint8_t instance);
    /** Player LED quadrant (1–4) from wireless receiver USB interface number (0,2,4,6). */
    uint8_t wireless_led_quadrant(uint8_t address, uint8_t instance);
    /** Keep all four wireless ports primed (RUMBLE_ENABLE + LED) until a pad connects. */
    void service_wireless_ports(uint8_t dev_addr);

    /**
     * Shared GIP OUT helpers for dedicated drivers (e.g. Victrix Gambit).
     * Sequence byte is assigned at packet[2] when assign_seq is true.
     */
    bool send_gip_out(uint8_t address, uint8_t instance, const uint8_t* packet, uint16_t len,
                      bool assign_seq = true);
    bool out_endpoint_ready(uint8_t address, uint8_t instance);
    void prepare_gip_session(uint8_t address, uint8_t instance);
    void mark_gip_power_sent(uint8_t address, uint8_t instance);
    void get_endpoint_info(uint8_t address, uint8_t instance, uint8_t* itf_num, uint8_t* ep_in,
                           uint8_t* ep_out, uint16_t* ep_in_size, uint16_t* ep_out_size);
    /** Current GIP OUT sequence counter (assigned to next send_gip_out with assign_seq). */
    uint8_t current_gip_seq(uint8_t address, uint8_t instance);
    /**
     * Arm interrupt IN via the shared XInput pipe (exactly one owner).
     * If already pending, returns true with reason "ALREADY_ARMED".
     */
    bool arm_gip_in(uint8_t address, uint8_t instance, const char** reason_out = nullptr);


    /**
     * If inbound options include GIP_OPT_ACK, send GIP ACK (0x01) using the *incoming*
     * sequence (not the next host sequence). Returns true if an ACK was submitted.
     * `bytes_received` / `remaining` match xone acknowledge payload fields.
     */
    bool send_gip_ack_if_requested(uint8_t address, uint8_t instance, const uint8_t* packet,
                                   uint16_t len, uint16_t bytes_received, uint16_t remaining);

    /**
     * Standard USB GET_INTERFACE (sync). Returns true and writes *alt_out on success.
     * Used by Victrix Gambit to log the active alt before SET_INTERFACE(1,0).
     */
    bool get_interface_alt(uint8_t daddr, uint8_t itf_num, uint8_t* alt_out);

    /**
     * Standard USB SET_INTERFACE — disable GIP/audio companion (Linux xpad/xone).
     * Async; complete_cb invoked when the control transfer finishes.
     * Scoped helper for dedicated drivers (e.g. Victrix Gambit); does not open audio EPs.
     */
    using set_interface_complete_cb_t = void (*)(uint8_t daddr, bool success, xfer_result_t result,
                                                 uintptr_t user_data);
    bool disable_gip_audio_interface(uint8_t daddr, uint8_t itf_num, uint8_t itf_alt,
                                     set_interface_complete_cb_t complete_cb, uintptr_t user_data);
    void cancel_gip_control(uint8_t daddr);

    //Wireless only atm
    void xbox360_chatpad_init(uint8_t address, uint8_t instance); 
    bool xbox360_chatpad_keepalive(uint8_t address, uint8_t instance);

    // User implemented callbacks

    TU_ATTR_WEAK void mount_cb(uint8_t dev_addr, uint8_t instance, const Interface *interface);
    TU_ATTR_WEAK void unmount_cb(uint8_t dev_addr, uint8_t instance, const Interface *interface);
    TU_ATTR_WEAK void report_sent_cb(uint8_t dev_addr, uint8_t instance, uint8_t const* report, uint16_t len);
    /**
     * OUT interrupt transfer finished (success or fail). Used by VictrixGambit completion-driven init.
     * `data`/`len` are the last submitted OUT buffer contents when available.
     */
    TU_ATTR_WEAK void out_xfer_complete_cb(uint8_t dev_addr, uint8_t instance, bool success,
                                           uint8_t const* data, uint16_t len);
    TU_ATTR_WEAK void xbox360w_connect_cb(uint8_t dev_addr, uint8_t instance);
    TU_ATTR_WEAK void xbox360w_disconnect_cb(uint8_t dev_addr, uint8_t instance);
    /** Called on every successful XInput IN transfer (keepalive for host idle watchdog). */
    TU_ATTR_WEAK void host_activity_cb(uint8_t dev_addr, uint8_t instance);
    void report_received_cb(uint8_t dev_addr, uint8_t instance, uint8_t const* report, uint16_t len);
    
}; // namespace tuh_xinput

#endif // _TUH_XINPUT_H_
